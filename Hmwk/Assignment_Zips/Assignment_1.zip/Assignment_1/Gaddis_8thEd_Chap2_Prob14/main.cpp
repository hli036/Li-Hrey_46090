/* 
 * File:   main.cpp
 * Author: Hrey Li
 * Created on June 29, 2015, 1:22 AM
 * Purpose: Homework, Personal Information
 */

//System Libraries
#include <iostream> //I/O Library
using namespace std;//Namespace for iostream

//User libraries

//Global constants

//Function prototypes

//Execution begins here!

int main(int argc, char** argv) {
    cout<<"Hrey Li\n"<<
          "1849 Walnut Avenue, Riverside, CA, 92507\n"<<
          "619-213-2064\n"<<
          "Statistics\n";
    
    return 0;
}

