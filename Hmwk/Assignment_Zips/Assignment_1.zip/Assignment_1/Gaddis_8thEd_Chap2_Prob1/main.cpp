/* 
 * File:   main.cpp
 * Author: Hrey Li
 * Created on June 28, 2015, 10:51 PM
 * Purpose: Homework, Sum of Two Numbers
 */

//System Libraries
#include <iostream> //I/O Library
using namespace std; //Namespace for iostream

//User libraries

//Global constants

//Function prototypes

//Execution begins here!

int main(int argc, char** argv) {
    //Declare and initialize variables
    int a = 50;
    int b = 100;
    int total; //Sum of the two variables

    //Calculate the total
    total = a + b;

    //Output the results
    cout<<"a = "<<a<<endl;
    cout<<"b = "<<b<<endl;
    cout<<"The sum of these two variables = "<<total<<endl;

    //Exit stage right!

    return 0;
}

